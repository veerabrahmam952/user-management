
export interface User {
  [key: string]: any;
}

export interface TableColumn {
  key: string;
  label: string;
  type: string;
}
